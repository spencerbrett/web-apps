CREATE INDEX idxOnSeller ON Item(SellerID);
CREATE INDEX idxOnEnds ON Item(Ends);
CREATE INDEX idxOnPrice ON Item(Buy_price);
CREATE INDEX idxOnItem ON Bid(ItemID);
