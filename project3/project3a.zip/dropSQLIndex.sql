DROP INDEX idxOnSeller ON Item;
DROP INDEX idxOnEnds ON Item;
DROP INDEX idxOnPrice ON Item;
DROP INDEX idxOnItem ON Bid;
