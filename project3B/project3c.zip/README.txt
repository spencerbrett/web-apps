Team Members:

Name: Spencer Brett
SID: 704071250

Name: Daniel Daskalov
SID: 504079134

NOTE: We are using one day grace period for this submission.

We are resubmitting Part A again because we have left a 10 limit on a query
for testing and we forgot to remove it.

We have made some minor fixes to our project 2 so we are resubmitting it as
well. We didn't actually input NULLs where they should be.
