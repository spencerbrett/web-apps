Team Members:

Name: Spencer Brett
SID: 704071250

Name: Daniel Daskalov
SID: 504079134

Submission for project 4 part A

Any changes to this part would involve fixes of any problems discovered in
part B or additional styling. Otherwise the requested functionality for part
A is there.

NOTE: we chose not to display item IDs on the auction search results page and
only display it in the actual item info page. This is subject to change.
